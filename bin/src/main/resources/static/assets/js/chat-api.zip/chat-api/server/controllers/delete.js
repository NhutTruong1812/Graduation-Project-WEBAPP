export default {
    deleteRoomById: async(req, res) => {},
    deleteMessageById: async(req, res) => {},
}