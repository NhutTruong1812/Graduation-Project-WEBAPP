const config = {
    db: {
        url: 'localhost:27017',
        name: 'chatdb'
    }
}

export default config